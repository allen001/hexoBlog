package com.icoding.springbootrabbitfanoutconsumber.mq;

import com.icoding.springbootrabbitfanoutconsumber.config.RabbitDeadLetterConfig;
import com.rabbitmq.client.Channel;
import lombok.extern.log4j.Log4j2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@RabbitListener(queues = RabbitDeadLetterConfig.REDIRECT_QUEUE)
@Component
@Log4j2
public class RedirectQueueConsumer {

    /**
     * 重定向队列和死信队列形参一致Integer number
     */
    @RabbitHandler
    public void fromDeadLetter(String msg, Channel channel, @Header(AmqpHeaders.DELIVERY_TAG) long tag, Message message){
        try {
            log.warn("RedirectQueueConsumer : {}", msg);
            // 对应的操作
           //System.out.println(1/0);
        }catch ( Exception ex) {
            try {
                //直接扔了，报警或者继续备份
                // 做消息冗余 存档（mongodb/es/mysql/oracle/redis）
                //channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
            }catch ( Exception ex1){
                ex1.printStackTrace();
            }
        }

    }

}