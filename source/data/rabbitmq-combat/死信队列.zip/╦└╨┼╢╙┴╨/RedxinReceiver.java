package com.icoding.springbootrabbitfanoutconsumber.mq;

import com.icoding.springbootrabbitfanoutconsumber.config.RabbitDeadLetterConfig;
import com.rabbitmq.client.Channel;
import lombok.extern.log4j.Log4j2;
import org.springframework.amqp.core.ExchangeTypes;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;


@Service
// 用RabbitListener来完成队列和交换机的定义和绑定关系以及设置交换机的类型
// autoDelete= true代表非持久化  false 持久化
@RabbitListener(bindings = @QueueBinding(
        value = @Queue(value="${mq.config.queue.red}",autoDelete ="false"),
        exchange =@Exchange(value = "${mq.config.exchange}",type = ExchangeTypes.DIRECT),
        key = "${mq.config.red.routekey}"
))
@Log4j2
public class RedxinReceiver {


    @Autowired
    RabbitTemplate rabbitTemplate;

    @RabbitHandler
    public void getMessage(String msg, Channel channel, @Header(AmqpHeaders.DELIVERY_TAG) long tag, Message message){
        try{
            System.out.println("red------接收到订单的消息了,内容是：" + message);
            //接收消息出错了
            throw new RuntimeException();
        }catch(Exception ex){
            /**
             * 这里对消息重入队列做设置，例如将消息序列化缓存至 Redis, 并记录重入队列次数
             * 如果该消息重入队列次数达到一定次数，比如3次，将不再重入队列，直接拒绝
             * 这时候需要对消息做补偿机制处理
             * channel.basicNack与channel.basicReject要结合越来使用
             **/
            // 如果你的消息没用在确认之前出现了错误，redelivered是false，代表消息没用确认成功，表明是第一次消费，可以直接打入到死信队列中去
            // 如果重启了消费者以后，redelivered就回变成了false说明消息已经收到但是一直没用确认，属于重复消费了。
            Boolean redelivered = message.getMessageProperties().getRedelivered();
            System.out.println("=============>" + redelivered);
            try {
                if (redelivered) {
                    /**
                     * 1. 对于重复处理的队列消息做补偿机制处理
                     * 2. 从队列中移除该消息，防止队列阻塞
                     */
                    // 消息已重复处理失败, 扔掉消息
                    channel.basicReject(message.getMessageProperties().getDeliveryTag(), false); // 拒绝消息
                    //log.error("消息[{}]重新处理失败，扔掉消息", msg);
                    //在这里预警，或者发短信
                    rabbitTemplate.convertAndSend(
                            RabbitDeadLetterConfig.DEAD_LETTER_EXCHANGE,
                            RabbitDeadLetterConfig.DEAD_LETTER_TEST_ROUTING_KEY,
                            message);
                }


                // redelivered != true,表明该消息是第一次消费
                if (!redelivered) {
                    // 消息重新放回队列
                    channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, true);
                    log.error("消息[{}]处理失败，重新放回队列", msg);
                }


            } catch (Exception exc) {
                exc.printStackTrace();
            }
        }
    }


}
