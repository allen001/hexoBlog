package com.icoding.springbootrabbitmqfanoutproducer.work;

import org.springframework.amqp.core.ExchangeTypes;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.stereotype.Component;

@Component

@RabbitListener(queues = "order.queue")
public class WorkLogService {

    @RabbitHandler
    public void sendMessage(String message) {
        System.out.println("log------------->" + message);
    }


}
