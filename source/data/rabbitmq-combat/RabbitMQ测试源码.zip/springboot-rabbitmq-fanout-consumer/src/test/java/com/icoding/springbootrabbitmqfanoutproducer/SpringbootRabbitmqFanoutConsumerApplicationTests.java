package com.icoding.springbootrabbitmqfanoutproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqFanoutConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
