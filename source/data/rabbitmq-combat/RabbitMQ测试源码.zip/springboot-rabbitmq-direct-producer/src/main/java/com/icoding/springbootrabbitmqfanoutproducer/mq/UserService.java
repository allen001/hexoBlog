package com.icoding.springbootrabbitmqfanoutproducer.mq;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.UUID;

@Component
public class UserService {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    // 1:定义交换
    @Value("${order.direct.exchange}")
    private String exchangeName;


    public void saveUser(int i) {
        // 你要发送订单信息
        String userId = "100";
        // 发送的数据
        String message = i + "===>保存用户：" + userId + ",日期是：" + new Date();
        System.out.println(message);
        // 发送消息
        rabbitTemplate.convertAndSend(exchangeName, "email", message);
        rabbitTemplate.convertAndSend(exchangeName, "log", message);
    }


}
