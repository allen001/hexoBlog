package com.icoding.springbootrabbitmqfanoutproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRabbitmqDirectProducerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootRabbitmqDirectProducerApplication.class, args);
    }

}
