package com.icoding.springbootrabbitmqfanoutproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRabbitmqFanoutProducerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootRabbitmqFanoutProducerApplication.class, args);
    }

}
