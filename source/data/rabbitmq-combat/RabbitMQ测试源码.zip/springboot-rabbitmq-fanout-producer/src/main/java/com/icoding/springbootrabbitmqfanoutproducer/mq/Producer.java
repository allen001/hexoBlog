package com.icoding.springbootrabbitmqfanoutproducer.mq;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.UUID;

@Component
public class Producer {

    @Autowired
    private RabbitTemplate rabbitTemplate;
    // AmqpTemplate是一个接口，最终找到实现类也就是：RabbitTemplate
    //@Autowired
    //private AmqpTemplate amqpTemplate;

    // 1:定义交换
    @Value("${order.fanout.exchange}")
    private String exchangeName;
    // 2:路由key
    private String routeKey = "";

    public void sendMessage(int i) {
        // 你要发送订单信息
        String orderId = UUID.randomUUID().toString();
        // 发送的数据
        String message = i + "===>你订单信息是：" + orderId + ",日期是：" + new Date();
        System.out.println(message);
        // 发送消息
        rabbitTemplate.convertAndSend(exchangeName, routeKey, message);
    }


}
