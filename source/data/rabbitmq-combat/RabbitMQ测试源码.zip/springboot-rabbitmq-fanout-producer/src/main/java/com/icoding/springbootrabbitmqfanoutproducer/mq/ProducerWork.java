package com.icoding.springbootrabbitmqfanoutproducer.mq;

import com.rabbitmq.client.Channel;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.UUID;

@Component
public class ProducerWork {

    @Autowired
    private RabbitTemplate rabbitTemplate;


    // 1:定义交换
    private String exchangeName ="";
    // 2:路由key
    private String queueName = "order.queue";

    public void sendMessage(int i, Channel channel) throws  Exception {
        // 你要发送订单信息
        String orderId = UUID.randomUUID().toString();
        // 发送的数据
        String message = i + "===>你订单信息是：" + orderId + ",日期是：" + new Date();
        System.out.println(message);
        // 这个qos，处理并发消息堆积的时候，这里面试：如果queue堆积很大的消息量，这个时候如果你直接启动消费者，
        // 可能会直接把消费者冲垮。我一个一个接收。 限流 如果执行执行快的，会直接在执行。
        //channel.basicQos(1,false);
        // 发送消息
        rabbitTemplate.convertAndSend(exchangeName, queueName, message);
    }


}
