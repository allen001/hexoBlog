package com.icoding.springbootrabbitmqfanoutproducer;

import com.icoding.springbootrabbitmqfanoutproducer.mq.Producer;
import com.icoding.springbootrabbitmqfanoutproducer.mq.ProducerWork;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqFanoutProducerApplicationTests {


    @Autowired
    private Producer producer;

    @Autowired
    private ProducerWork producerWork;


    @Test
    void contextLoads() {

        for (int i = 0; i < 100; i++) {
            try{
                Thread.sleep(1000);
            }catch(Exception ex){
               ex.printStackTrace();
            }
            producer.sendMessage(i);
        }
    }

    @Test
    void workdqueue(){

        for (int i = 0; i < 100; i++) {
            try{
                Thread.sleep(1000);
            }catch(Exception ex){
                ex.printStackTrace();
            }
            producerWork.sendMessage(i);
        }
    }

}
