package com.icoding.springbootrabbitmqfanoutproducer.order;


import com.icoding.springbootrabbitmqfanoutproducer.dead.RabbitDeadLetterConfig;
import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.ExchangeTypes;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

// 这里做什么？
// 1：会把申请的队列和交换机进行绑定
// 2：确定消息的模式 fanout direct topic
// 3: 确定队列queue的持久性 autoDelete

@Component
@RabbitListener(bindings = @QueueBinding(value = @Queue(value = "${order.direct.order.queue}", autoDelete = "false"),
        exchange = @Exchange(value = "${order.direct.exchange}", type = ExchangeTypes.DIRECT),
        key = "order"
))

public class OrderService {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @RabbitHandler
    public void sendMessage(String msg, Channel channel, @Header(AmqpHeaders.DELIVERY_TAG) long tag, Message message) {
        /*
         1: 当消费在处理消息的过程，rabbitmq会怎么样？
         2： 怎么解决？
         3： 因为rabbitmq里面有确认机制，ack 默认情况：是自动ack，


          做这么多努力：就算是在网络出现问题和故障的情况，也能让数据达到最终一致性。

          1： 可靠消费
          正常情况下：消费者正常，就直接告诉rabbitmq服务去收到消息，就自动确认，并且消息删掉。
          异常情况下：消费者异常，rabbitmq 服务一直收不自动确认，就走rabbitmq 的basicNack重试机制，会把消息不停的重新发送给消费进行消费
          就会出现 "死循环" 如果你消费者是集群可能重试别的服务器。如果重试服务器也会重复。一般在是非常危险，但是出异常也是没有办法去避免的事情？
          怎么解决？
          1: 开启出错的重试次数。如果达到重试次数直接扔掉。 (一般不建议用这种方式。)
          2: try/catch自己处理(利用消息转移 + 消息重试 + 死信队列 + 重定向队列 + 人工干预 + 预警)


          2: 可靠生产 解决的问题是(rabbitmq挂掉的情况?)---
           // (分布式事务) rabbitmq不事务回滚的分布式事务，
           // 分布式事务两种：不回滚（rabbitmq/activemq /tcc）  回滚（2pc/3pc/异步校对/atomicok）
           a: ack手动 + reture/confirm 机制
           b: 消息冗余 + 定时任务重发(3/5)

        */
        try {
            System.out.println("order------------->" + message);
            System.out.println(1 / 0);
        } catch (Exception ex) {
            // 发送消息message消息头，每一个消息都有一个tag 类似主键，这个tag的作用可用来，删除，转移，拒绝等。
            // 1: message 是一个Message对象, message.getMessageProperties().getRedelivered() 获取或消息的状态
            // 如果消息第一次出现错误，它是false.代表消息还没有重试过。如果 true 消息已经重试过了（你调用消息的basicNack 重试机制）。
            Boolean redelivered = message.getMessageProperties().getRedelivered();
            System.out.println("=============>" + redelivered);
            try {
                if (redelivered) {
                    channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
                    System.out.println("消息["+msg+"]重新处理失败，扔 掉消息");
                    //消息转移 -- 死信队列 (死信队列逻辑和我们逻辑一模一样的
                    //消息转移---mysql/oracle/
                    rabbitTemplate.convertAndSend(RabbitDeadLetterConfig.DEAD_LETTER_EXCHANGE,
                            RabbitDeadLetterConfig.DEAD_LETTER_TEST_ROUTING_KEY,msg);
                }

                if (!redelivered) {
                    // 消息重新放回队列
                    channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, true);
                    System.out.println("消息["+msg+"]重新放回队");
                }
            } catch (Exception exc) {
                exc.printStackTrace();
            }
        }

    }

}


