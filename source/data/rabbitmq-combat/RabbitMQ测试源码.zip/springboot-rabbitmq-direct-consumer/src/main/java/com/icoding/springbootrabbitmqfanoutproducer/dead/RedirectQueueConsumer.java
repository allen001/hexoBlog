package com.icoding.springbootrabbitmqfanoutproducer.dead;

import com.rabbitmq.client.Channel;
import lombok.extern.log4j.Log4j2;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

@RabbitListener(queues = RabbitDeadLetterConfig.REDIRECT_QUEUE)
@Component
@Log4j2
public class RedirectQueueConsumer {

    /**
     * 重定向队列和死信队列形参一致Integer number
     */
    @RabbitHandler
    public void fromDeadLetter(String msg, Channel channel, @Header(AmqpHeaders.DELIVERY_TAG) long tag, Message message){
        try {
            log.warn("RedirectQueueConsumer : {}", msg);
            // 对应的操作
           System.out.println(1/0);
        }catch ( Exception ex) {
            try {
                // 报警或者继续备份  重试三个地方说明的消息的内容的问题了。而不代码
                // 做消息冗余 存档（mongodb/es/mysql/oracle/redis）
                channel.basicReject(message.getMessageProperties().getDeliveryTag(), false);
                // 短信报警。 异常表（监控 ELK） + 消息确认表 定时器去发
                // elk 日志统计分析   logstash kinba
            }catch ( Exception ex1){
                ex1.printStackTrace();
            }
        }

    }

}