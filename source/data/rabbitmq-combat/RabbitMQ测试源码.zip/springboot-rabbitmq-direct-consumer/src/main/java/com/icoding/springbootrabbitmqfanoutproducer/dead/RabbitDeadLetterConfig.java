package com.icoding.springbootrabbitmqfanoutproducer.dead;
import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.SpringBootConfiguration;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @Configuration 和 @SpringBootConfiguration是等价没区别。
 * @SpringBootConfiguration 被申明是一配置类 appllicaitonContext.xml
 *
 * 1: xml + <bean> ---- ---- 把它们装配springioc容器中
 * 2: @Configuration + @Bean    ---- 把它们装配springioc容器中
 * 3: @Import + @Configuration  ---- 把它们装配springioc容器中
 * 4: selector机制+ @Configuration  ---- 把它们装配springioc容器中
 * starter机制  selector机制+ @EnableAutoConfiguration
 * 死信队列的配置
 */
@SpringBootConfiguration
public class RabbitDeadLetterConfig {

    // 定义死信队列的交换机的名字 direct模型
    public static final String DEAD_LETTER_EXCHANGE = "TDL_EXCHANGE";
    // 死信队列的路由key
    public static final String DEAD_LETTER_TEST_ROUTING_KEY = "TDL_KEY";
    // 死信队列
    public static final String DEAD_LETTER_QUEUE = "TDL_QUEUE";

    // 重定向队列路由key
    public static final String DEAD_LETTER_REDIRECT_ROUTING_KEY = "TKEY_R";
    // 重定向队列
    public static final String REDIRECT_QUEUE = "TREDIRECT_QUEUE";


    /**
     *
     * 消息堆积：请注意不继续启动消费者，一一定感觉做限流 qos机制打开。
     * 死信队列跟交换机类型没有关系 不一定为directExchange  不影响该类型交换机的特性.
     */
    @Bean("deadLetterExchange")
    public Exchange deadLetterExchange() {
        return ExchangeBuilder.directExchange(DEAD_LETTER_EXCHANGE).durable(true).build();
    }

    @Bean("deadLetterQueue")
    public Queue deadLetterQueue() {
        Map<String, Object> args = new HashMap<>(2);
        //x-dead-letter-exchange 声明  死信队列Exchange
        args.put("x-dead-letter-exchange", DEAD_LETTER_EXCHANGE);
        //x-dead-letter-routing-key    声明 死信队列抛出异常重定向队列的routingKey(TKEY_R)
        args.put("x-dead-letter-routing-key", DEAD_LETTER_REDIRECT_ROUTING_KEY);
        return QueueBuilder.durable(DEAD_LETTER_QUEUE).withArguments(args).build();
    }

    @Bean("redirectQueue")
    public Queue redirectQueue() {
        return QueueBuilder.durable(REDIRECT_QUEUE).build();
    }

    /**
     * 死信队列绑定到死信交换器上.
     *
     * @return the binding
     */
    @Bean
    public Binding deadLetterBinding() {
        return new Binding(DEAD_LETTER_QUEUE, Binding.DestinationType.QUEUE, DEAD_LETTER_EXCHANGE, DEAD_LETTER_TEST_ROUTING_KEY, null);

    }

    /**
     * 将重定向队列通过routingKey(TKEY_R)绑定到死信队列的Exchange上
     *
     * @return the binding
     */
    @Bean
    public Binding redirectBinding() {
        return new Binding(REDIRECT_QUEUE, Binding.DestinationType.QUEUE, DEAD_LETTER_EXCHANGE, DEAD_LETTER_REDIRECT_ROUTING_KEY, null);
    }

}
