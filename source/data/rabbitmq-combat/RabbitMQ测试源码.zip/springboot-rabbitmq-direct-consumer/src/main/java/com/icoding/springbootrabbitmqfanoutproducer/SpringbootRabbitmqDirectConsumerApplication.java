package com.icoding.springbootrabbitmqfanoutproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRabbitmqDirectConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootRabbitmqDirectConsumerApplication.class, args);
    }

}
